# Agent Prompt Template

## Role
## Mission
## Inputs
## Constraints
## Preferred tools
## Fallback behavior
## Output format
## Failure behavior
## Examples
