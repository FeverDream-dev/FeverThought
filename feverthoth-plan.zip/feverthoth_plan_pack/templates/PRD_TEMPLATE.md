# PRD Template

## Summary
## Problem
## Opportunity
## Users
## Jobs to be done
## Goals
## Non-goals
## Success metrics
## User stories
## Functional requirements
## UX requirements
## Technical constraints
## Risks
## Open questions
## Rollout plan
