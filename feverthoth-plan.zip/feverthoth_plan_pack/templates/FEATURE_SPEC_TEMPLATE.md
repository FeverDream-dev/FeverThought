# Feature Spec Template

## Feature name
## Owner
## User value
## Scope
## Out of scope
## UX flow
## Technical design
## Data model changes
## API/contracts
## Risks
## Acceptance criteria
## QA notes
