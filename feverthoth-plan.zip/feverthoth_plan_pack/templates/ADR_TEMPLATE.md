# ADR Template

## Title
## Status
## Context
## Decision
## Consequences
## Alternatives considered
## Follow-up actions
