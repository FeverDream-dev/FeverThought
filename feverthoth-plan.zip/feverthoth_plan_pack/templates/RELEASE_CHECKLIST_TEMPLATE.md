# Release Checklist Template

- [ ] Version bumped
- [ ] Changelog updated
- [ ] CI green
- [ ] Artifacts generated
- [ ] Install smoke tests passed
- [ ] Provider smoke tests passed
- [ ] Known issues documented
- [ ] Release notes drafted
- [ ] Rollback plan ready
