# Milestones

## Milestone A: Shell + editor
Definition of done:
- app launches cross-platform
- project opens
- editor works
- file tree works
- settings persist

## Milestone B: Rust-first IDE credibility
Definition of done:
- Rust Analyzer integrated
- diagnostics visible
- formatting/basic code actions function
- terminal stable
- git status visible

## Milestone C: AI-first identity
Definition of done:
- provider registry works
- Ollama local path works
- AI plan flow works
- clarification UI works
- basic file edits from AI work with review

## Milestone D: visual intelligence + MCP
Definition of done:
- screenshot analysis local path works
- Playwright/Chrome MCP hooks work
- browser tasks prefer MCP over vision
- logs and permissions are visible

## Milestone E: shippable beta
Definition of done:
- GitHub Actions release workflow works
- Windows/macOS/Linux artifacts produced
- onboarding solid
- crash/bug rate acceptable
