# Delivery Plan

## Team sequencing idea

### Week block 1
- app shell
- design tokens
- repo scaffolding
- editor wrapper
- workspace open/save

### Week block 2
- LSP bridge
- terminal
- settings
- project tree
- command palette baseline

### Week block 3
- provider registry
- Ollama integration
- AI tab shell
- clarification widget
- planner agent

### Week block 4
- screenshot analysis
- cloud adapters
- diff review flow
- audit log events

### Week block 5
- MCP integration
- browser task routing
- Git summarizer
- support UI

### Week block 6
- CI/CD hardening
- packaging
- cross-platform QA
- docs cleanup

## Delivery rule
Always keep the app runnable, even if incomplete.
