# Backlog Epics

## Epic 1: App shell and workspace foundation
Acceptance:
- launch app
- open project
- render file tree
- open and save file
- recent projects remembered

## Epic 2: Design system and visual identity
Acceptance:
- token system created
- light theme implemented
- dark theme scaffolded
- major surfaces/components skinned

## Epic 3: Editor and navigation
Acceptance:
- Monaco integration
- tabs
- splits
- search
- breadcrumbs
- outline

## Epic 4: Rust IDE intelligence
Acceptance:
- Rust Analyzer operational
- diagnostics
- hover
- definition
- formatting

## Epic 5: AI provider platform
Acceptance:
- provider registry
- auth/configuration UI
- model selection
- capability detection
- fallback logic

## Epic 6: AI planning workflow
Acceptance:
- intent clarifier
- planner
- repo cartographer
- implementer
- reviewer baseline
- diff review

## Epic 7: Local vision pipeline
Acceptance:
- screenshot input
- Qwen2.5-VL path
- structured JSON summary
- privacy controls

## Epic 8: MCP browser tooling
Acceptance:
- Playwright MCP adapter
- Chrome DevTools MCP adapter
- permission model
- logs
- fallback policy

## Epic 9: Source control and terminal trust workflows
Acceptance:
- git status
- diff view
- commit suggestions
- AI command approval

## Epic 10: CI/CD and packaging
Acceptance:
- release workflow
- Windows/macOS/Linux artifacts
- GitHub Releases upload
- checksums
