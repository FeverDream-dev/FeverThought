# Go-to-Market Notes

## Early audience
- AI power users
- indie makers
- design-forward developers
- privacy-conscious builders
- Rust-curious developers

## Launch channels
- GitHub release page
- demo videos
- X/Twitter dev audience
- Reddit/Show HN style launches if appropriate
- design/dev communities that care about novel UI
