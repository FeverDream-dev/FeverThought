# Estimates and Team Shape

## Lean team shape
- 1 product/UX lead
- 1 visual designer
- 2 Rust/Tauri engineers
- 1 frontend/React engineer
- 1 AI/platform engineer
- shared QA support

## If solo or tiny team
Sequence strictly:
1. shell/editor/workspace
2. Rust Analyzer
3. settings/terminal/git basics
4. provider registry
5. AI clarification + planning
6. local screenshot summary
7. cloud adapters
8. packaging

## Estimate cautions
Biggest schedule uncertainty drivers:
- cross-platform packaging
- MCP integration edge cases
- polished visual system work
- AI trust UX
- signing/notarization

## Scope defense
If under pressure, keep:
- editor
- Rust Analyzer
- terminal
- AI clarification
- plan-first flow
- Ollama local path
- one or two cloud adapters
- release artifacts
