# Roadmap

## Phase 0: Foundations and decisions
- finalize name/brand
- lock stack decisions
- create repo and CI skeleton
- implement design system tokens
- set up app shell

## Phase 1: Core IDE baseline
- open project
- Monaco editor
- tabs and splits
- terminal
- search
- settings
- Rust Analyzer integration
- workspace services

## Phase 2: AI-first core
- provider abstraction
- Ollama support
- AI panel baseline
- clarification widget
- planner flow
- screenshot-to-summary local vision path

## Phase 3: Tooling and trust
- MCP integration
- browser/UI agent
- diff review and change approval
- audit logs
- git summarizer
- provider transparency UI

## Phase 4: Packaging and polish
- release workflows
- platform installers
- first-run experience polish
- support docs
- beta program

## Phase 5: v1 stabilization
- bug fixing
- performance tuning
- UX refinements
- accessibility pass
- signing/notarization hardening
