# Master Build Brief

## One-line pitch

**FeverThoth IDE** is a cross-platform, Rust-centered, AI-first IDE with a premium 2000s glassy retro-futurist visual language and a deeper agentic workflow than typical “chat in editor” tools.

## Product thesis

Most AI coding tools currently optimize for:
- novelty
- raw code generation
- low-friction “ask and patch”
- flat modern UI sameness

FeverThoth IDE should instead optimize for:
- clarity before code
- structured planning
- beautiful and memorable interface identity
- local + cloud AI interoperability
- trust and privacy
- making non-experts feel capable without making experts feel trapped

## Core product pillars

### 1. Simplicity without infantilization
The product should not assume the user already understands model routing, context windows, MCP, or language servers. Advanced behavior should exist, but the default path should feel obvious.

### 2. AI as a workflow partner, not a novelty sidebar
The AI tab must be able to:
- clarify ambiguous user intent
- plan before touching files
- inspect the repo
- use structured tools
- summarize changes
- stay transparent about what it is doing

### 3. Rust-centered reliability
The backend orchestration, process management, provider handling, security-sensitive logic, and release packaging should be centered around Rust for performance and operational confidence.

### 4. A distinctive visual identity
The UI should feel like it belongs to an alternate future where developer tools embraced glossy optimism instead of converging on monochrome flatness.

### 5. Local-first privacy options
Users should be able to use local models via Ollama and keep screenshots local by default, only sending distilled structured summaries to cloud providers unless they explicitly allow more.

## MVP must-haves

- open local folder/workspace
- file explorer
- Monaco-based editor
- multi-tab editing
- split panes
- terminal
- Rust Analyzer integration
- general LSP adapter architecture
- search/replace
- Git status and diffs
- settings UI
- AI tab with plan-first workflow
- Ollama integration
- local screenshot-to-structured-text pipeline
- cloud provider adapter layer
- GitHub Actions release pipeline

## Naming decision

Primary recommendation: **FeverThoth IDE**

Why:
- “Fever” ties directly to FeverDream
- “Thoth” evokes writing, wisdom, records, and structured knowledge
- it sounds like a tool rather than a fantasy game
- it is memorable and brandable

Secondary backup names:
- FeverRa
- FeverAnkh
- DreamThoth
- ThothForge
- ThothGlass

## Product differentiators

1. Local vision is used as a **visual interpreter**, not a monolithic planner.
2. Browser/web tasks should prefer **MCP tools** over blind screenshot interpretation.
3. The AI should **ask better questions** when user intent is underspecified.
4. The design language is intentionally distinctive and emotionally memorable.
5. The system supports future provider expansion through clean adapters and addons.

## Target users

- solo builders
- indie hackers
- designer-developers
- prompt-heavy “vibe coders”
- developers who want less terminal spelunking and more guided iteration
- teams that want local/private AI options

## Success criteria for v1

- User can install from GitHub Releases without manual compilation.
- User can open a Rust project and get IDE basics working.
- User can use AI tab to plan, clarify, and modify code.
- User can connect Ollama and at least one cloud provider.
- User can see a project screenshot summarized locally.
- User can run release builds for Windows/macOS/Linux from CI.
