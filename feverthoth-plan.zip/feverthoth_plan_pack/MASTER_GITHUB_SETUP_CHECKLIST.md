# Master GitHub Setup Checklist

## Repository creation
- [ ] Create GitHub org/repo under `FeverDream`
- [ ] Reserve repository name (recommended: `feverthoth-ide`)
- [ ] Add description and homepage
- [ ] Add topics: `rust`, `tauri`, `ide`, `ai`, `ollama`, `mcp`, `react`, `typescript`

## Branching
- [ ] Protect `main`
- [ ] Require PR reviews
- [ ] Require status checks
- [ ] Disallow force pushes on protected branches
- [ ] Enable merge queue later if needed

## Repository files
- [ ] `README.md`
- [ ] `LICENSE`
- [ ] `CONTRIBUTING.md`
- [ ] `CODE_OF_CONDUCT.md`
- [ ] `SECURITY.md`
- [ ] `.editorconfig`
- [ ] `.gitignore`
- [ ] issue templates
- [ ] PR template

## Secrets
- [ ] `TAURI_PRIVATE_KEY`
- [ ] `TAURI_KEY_PASSWORD`
- [ ] macOS signing secrets
- [ ] Apple notarization credentials
- [ ] Windows signing secrets if used
- [ ] provider test tokens for CI smoke tests, if safe
- [ ] release token strategy review

## CI/CD
- [ ] lint workflow
- [ ] test workflow
- [ ] release workflow
- [ ] artifact naming conventions
- [ ] GitHub Releases automation
- [ ] draft release mode for early iterations
- [ ] changelog generation

## Release channels
- [ ] nightly
- [ ] beta
- [ ] stable

## Security / quality
- [ ] Dependabot
- [ ] CodeQL
- [ ] cargo audit
- [ ] npm audit policy
- [ ] secret scanning
- [ ] SBOM strategy defined

## Documentation
- [ ] docs folder or planning pack imported
- [ ] architecture decision records
- [ ] onboarding guide
- [ ] release checklist
