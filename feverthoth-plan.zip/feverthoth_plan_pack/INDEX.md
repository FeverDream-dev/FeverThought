# Index

## Root
- `README.md` — orientation and usage
- `MASTER_BUILD_BRIEF.md` — condensed but authoritative top-level brief
- `MASTER_IMPLEMENTATION_PROMPT.md` — full coding-agent prompt for bootstrapping the repo
- `MASTER_GITHUB_SETUP_CHECKLIST.md` — GitHub/release/repo checklist
- `SOURCES_AND_DECISIONS.md` — current ecosystem assumptions and source links

## Product
- `product/01-vision.md`
- `product/02-branding-and-naming.md`
- `product/03-personas.md`
- `product/04-jobs-to-be-done.md`
- `product/05-user-stories.md`
- `product/06-feature-matrix.md`
- `product/07-non-goals.md`
- `product/08-success-metrics.md`
- `product/09-risk-register.md`
- `product/10-competitive-benchmark.md`

## Design
- `design/01-visual-direction.md`
- `design/02-design-tokens.md`
- `design/03-information-architecture.md`
- `design/04-screen-map.md`
- `design/05-component-specs.md`
- `design/06-accessibility.md`
- `design/07-microinteractions.md`
- `design/08-empty-states-and-copy.md`

## Engineering
- `engineering/01-system-architecture.md`
- `engineering/02-monorepo-structure.md`
- `engineering/03-data-models-and-state.md`
- `engineering/04-editor-subsystem.md`
- `engineering/05-lsp-dap-terminal-git.md`
- `engineering/06-plugin-and-addon-system.md`
- `engineering/07-settings-storage.md`
- `engineering/08-security-privacy.md`
- `engineering/09-observability-and-telemetry.md`

## AI
- `ai/01-provider-abstraction.md`
- `ai/02-local-vision-strategy.md`
- `ai/03-cloud-provider-adapters.md`
- `ai/04-agent-orchestration.md`
- `ai/05-clarification-ux.md`
- `ai/06-context-engineering.md`
- `ai/07-mcp-integration.md`
- `ai/08-prompt-pack.md`
- `ai/09-safety-and-permissioning.md`

## Ops
- `ops/01-github-repo-setup.md`
- `ops/02-ci-cd-and-releases.md`
- `ops/03-packaging-matrix.md`
- `ops/04-github-actions-workflows.md`
- `ops/05-versioning-and-release-train.md`
- `ops/06-qa-strategy.md`
- `ops/07-test-matrix.md`
- `ops/08-support-runbooks.md`

## Management
- `management/01-roadmap.md`
- `management/02-milestones.md`
- `management/03-delivery-plan.md`
- `management/04-estimates-and-team-shape.md`
- `management/05-backlog-epics.md`

## Templates
- `templates/PRD_TEMPLATE.md`
- `templates/ADR_TEMPLATE.md`
- `templates/FEATURE_SPEC_TEMPLATE.md`
- `templates/RELEASE_CHECKLIST_TEMPLATE.md`
- `templates/AGENT_PROMPT_TEMPLATE.md`

## GitHub meta docs
- `.github/ISSUE_TEMPLATE_BUG.md`
- `.github/ISSUE_TEMPLATE_FEATURE.md`
- `.github/PULL_REQUEST_TEMPLATE.md`
