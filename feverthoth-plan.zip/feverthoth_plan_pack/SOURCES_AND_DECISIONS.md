# Sources and Decisions

This document records the major ecosystem assumptions used in the planning pack.

## Confirmed/current directional choices

### Tauri v2
Use Tauri v2 as the desktop shell because it is explicitly positioned for fast, cross-platform desktop apps using a web frontend plus Rust core.

Official docs:
- https://v2.tauri.app/
- https://v2.tauri.app/start/
- https://v2.tauri.app/distribute/pipelines/github/

### Ollama local vision candidates
Use **Qwen2.5-VL** as the primary local screenshot interpreter.
Keep **Gemma 3** and **Llama 3.2 Vision** as secondary options.

Official model pages:
- https://ollama.com/library/qwen2.5vl
- https://ollama.com/library/gemma3
- https://ollama.com/library/llama3.2-vision

### MCP browser tools
Prefer MCP-based browser tooling before vision for browser workflows.

Official references:
- https://playwright.dev/docs/getting-started-mcp
- https://playwright.dev/mcp/introduction
- https://github.com/ChromeDevTools/chrome-devtools-mcp/

### Cloud providers
Planned provider support is based on publicly documented APIs or product pages:
- Z.AI docs: https://docs.z.ai/api-reference/introduction
- Z.AI Coding Plan overview / quick start:
  - https://docs.z.ai/devpack/overview
  - https://docs.z.ai/devpack/quick-start
- OpenAI Codex:
  - https://developers.openai.com/codex
  - https://developers.openai.com/codex/cli
- OpenRouter:
  - https://openrouter.ai/docs/api/reference/overview
  - https://openrouter.ai/docs/quickstart
  - https://openrouter.ai/docs/guides/routing/provider-selection

### Packaging
Tauri distribution docs support Linux formats including AppImage, Debian, and RPM, as well as GitHub-based release pipelines.
Official references:
- https://v2.tauri.app/distribute/
- https://v2.tauri.app/distribute/appimage/
- https://v2.tauri.app/distribute/debian/
- https://v2.tauri.app/distribute/rpm/

## Notes
- “ThinkinMCP” is treated as a reserved integration slot rather than a hard-coded dependency, because a single canonical public reference under that exact branding was not locked down during research.
- The planning pack is intentionally modular so individual decisions can be swapped without rewriting the whole strategy.
