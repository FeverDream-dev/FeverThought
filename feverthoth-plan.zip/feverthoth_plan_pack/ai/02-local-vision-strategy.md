# Local Vision Strategy

## Mission
Turn screenshots and other visual inputs into **structured textual context** that can be safely fed into stronger text-first planners.

## Default local model
**Qwen2.5-VL** should be the default first recommendation for local visual understanding.

## Secondary options
- **Gemma 3** for users who want a lighter multimodal option
- **Llama 3.2 Vision** for users who prefer a Llama-family local route

## Why vision is a support layer, not the boss
The local vision model is best used for:
- what is visible
- likely UI structure
- readable text on screen
- possible visible errors
- what changed between screenshots
- candidate follow-up questions

It is **not** the default master planner for repo-wide implementation.

## Input types
- uploaded screenshots
- live app captures
- side-by-side before/after captures
- browser screenshots when MCP is unavailable
- design mock screenshots

## Output schema
```json
{
  "visible_text": [],
  "ui_elements": [],
  "detected_errors": [],
  "likely_context": "",
  "user_goal_hypothesis": [],
  "ambiguity_flags": [],
  "followup_questions": [],
  "relevant_regions": [
    {
      "label": "",
      "reason": ""
    }
  ]
}
```

## Privacy defaults
- store raw screenshot only locally unless user changes the policy
- send only summary JSON to cloud text provider by default
- expose a toggle for “allow raw screenshot to cloud for this request”

## Performance strategy
- allow model-size presets
- offer “fast summary” and “deep summary” modes
- cache image hash to summary mapping for repeat inspections
