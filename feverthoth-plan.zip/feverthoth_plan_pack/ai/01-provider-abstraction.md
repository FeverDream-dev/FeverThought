# Provider Abstraction

## Goal
Support multiple local and cloud model providers without contaminating the rest of the system with provider-specific conditionals.

## Provider interface
Each provider adapter should implement:
- authenticate/configure
- list models
- report capability flags
- stream text responses
- accept structured tool definitions if supported
- accept JSON mode if supported
- normalize errors
- expose rate limit or quota hints if available

## Capability flags
- supports_text
- supports_vision
- supports_tools
- supports_reasoning
- supports_json_mode
- supports_streaming
- supports_mcp_bridge
- supports_large_context
- supports_file_inputs

## Normalized request model
```json
{
  "provider": "openrouter",
  "model": "provider/model-name",
  "mode": "chat|reasoning|coding|vision-summary",
  "messages": [],
  "tools": [],
  "attachments": [],
  "jsonSchema": null,
  "temperature": 0.2,
  "stream": true
}
```

## Fallback policy
- if preferred provider is unavailable, try configured fallback only when task semantics still match
- never silently send screenshots/raw files to a cloud provider if the privacy policy for that workspace disallows it
- if tool use is required, route only to providers that support tools

## Why this matters
The rest of the app should ask:
> “What capabilities are needed?”

not:
> “Which vendor are we hard-coded to right now?”
