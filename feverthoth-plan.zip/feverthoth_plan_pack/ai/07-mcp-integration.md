# MCP Integration

## Goal
Treat MCP as a first-class tool layer for structured interactions with external environments.

## Built-in targets
- Chrome DevTools MCP
- Playwright MCP
- ThinkinMCP slot
- AgentMCP slot

## Priority policy
For browser tasks:
1. Playwright MCP or Chrome DevTools MCP
2. local screenshot vision
3. pure text reasoning only

## Integration requirements
- server discovery/config
- enable/disable per workspace
- permission model
- logs
- health checks
- tool inventory
- retry/backoff
- structured error reporting

## UI expectations
Users should be able to see:
- which MCP server is active
- which tools were used
- when a server failed
- what permissions were granted

## Failure strategy
If MCP is unavailable:
- explain what failed
- offer fallback path
- note any reduced confidence
