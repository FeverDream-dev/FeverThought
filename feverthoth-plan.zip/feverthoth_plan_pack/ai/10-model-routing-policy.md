# Model Routing Policy

## Inputs
- task type
- privacy policy
- tool need
- vision need
- context size
- user-pinned preferences
- latency/cost mode

## Example routing
- screenshot summary -> local qwen2.5-vl
- browser inspection -> Playwright/Chrome MCP
- heavy coding plan -> Z.AI Coding Plan or Codex depending user config
- broad model access fallback -> OpenRouter
- offline/local text request -> Ollama local text model

## Guardrails
- never ignore explicit user/provider pin
- never send raw images to cloud without permission
- prefer structured tool outputs over hallucinated descriptions
