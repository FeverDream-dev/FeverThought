# Context Engineering

## Goal
Feed each model the minimum context that still gives it the best chance of doing the right thing.

## Context sources
- user request
- clarified answers
- workspace summary
- relevant file snippets
- architecture notes
- diagnostics/errors
- git diff state
- screenshot summary JSON
- MCP output
- explicit constraints

## Context assembly rules
- prioritize relevance over bulk
- summarize repo structure before dumping file text
- include current file and nearby dependencies first
- include explicit “do not change” constraints
- separate facts from assumptions
- include test/validation instructions when available

## Token strategy
Use more tokens for planning when it materially improves execution quality.
The product should not over-optimize for token thrift during planning-heavy tasks.

## Session memory
Persist high-value short summaries:
- user stated preferences
- repo conventions discovered
- confirmed technology stack
- pending unresolved questions

Do not blindly persist everything.
