# Clarification UX

## Why it matters
Most AI coding failures start with bad assumptions, not bad syntax.

## Trigger conditions
Ask a clarification question when:
- the target language is unclear
- the desired output type is unclear
- the scope is unclear
- there are multiple plausible implementation strategies
- user intent conflicts with repo constraints
- destructive changes might be involved

## Clarification widget structure
- question
- why I’m asking
- at least 3 suggested options
- custom free-text field
- optional “best guess” continue action
- optional remember-for-this-session checkbox

## Example question patterns
### Language ambiguity
“What language should I target for this feature?”
Options:
- Rust
- TypeScript
- Python
- Something else

### Scope ambiguity
“Do you want a small patch or a full refactor?”
Options:
- Small patch
- Moderate cleanup
- Full refactor
- Not sure — propose a plan

### UI preference ambiguity
“What style direction should I aim for?”
Options:
- Keep current style
- More premium/glossy
- Minimal/clean
- Match screenshot reference

## Quality standard
A clarification should:
- eliminate the biggest risk of wrong work
- be answerable in seconds
- not overwhelm the user
