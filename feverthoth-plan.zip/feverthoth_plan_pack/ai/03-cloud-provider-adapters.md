# Cloud Provider Adapters

## Planned providers
- Z.AI Coding Plan
- Ollama Cloud
- Gemini
- OpenAI Codex
- OpenRouter

## Adapter requirements
Each adapter must specify:
- auth method
- endpoint families
- supported modes
- tool call behavior
- streaming support
- error normalization
- quota/rate signals
- model discovery approach
- recommended default model(s)

## Provider-specific notes

### Z.AI Coding Plan
Treat this as a first-class coding-oriented provider path, not a generic chat fallback.

### Ollama Cloud
Useful for users who like the Ollama ecosystem and want cloud reach.

### Gemini
Strong candidate for multimodal or long-context workflows depending on available model.

### OpenAI Codex
Treat as coding-specialized provider with strong agentic workflow alignment.

### OpenRouter
Useful as a routing/meta-provider with broad model access and fallback potential.

## Provider selection policy
The router should consider:
- task type
- privacy policy
- tool requirements
- latency preference
- context size need
- local availability
- cost preference
- user-pinned provider choices
