# Safety and Permissioning

## Permission classes
- read workspace files
- write workspace files
- run shell command
- run browser MCP tool
- send data to cloud provider
- upload raw screenshot
- commit changes
- push changes

## Default policies
- read operations: allowed within workspace
- write operations: allowed after plan/approval policy
- shell commands: require review
- raw screenshot cloud upload: denied by default
- git push: always requires explicit user action

## Risk tiers
### Low
single-file edit, local context only

### Medium
multi-file refactor, shell test commands

### High
deletions, dependency changes, git operations, external uploads

## UX requirement
Permissions should feel understandable, not like firewall dialogs. The user must know:
- what action is proposed
- why it is needed
- what data leaves the machine, if any
