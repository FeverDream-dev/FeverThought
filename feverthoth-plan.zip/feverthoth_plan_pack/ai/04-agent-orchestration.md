# Agent Orchestration

## Agent roster
- Intent Clarifier
- Planner
- Repo Cartographer
- Tool Router
- Implementer
- Reviewer/Critic
- Browser/UI Agent
- Git Summarizer

## Pipeline

### Step 1: Intake
Parse user request and detect:
- ambiguity
- requested outcome
- repo scope
- need for UI/browser inspection
- risk level
- destructive potential

### Step 2: Clarify if needed
If ambiguity is material, pause and ask a focused question with suggestions.

### Step 3: Gather context
Repo Cartographer builds:
- relevant files list
- architecture notes
- important commands
- probable change surface

### Step 4: Plan
Planner generates:
- objective
- assumptions
- steps
- validation method
- files likely affected
- risks

### Step 5: Execute
Implementer proposes and/or applies changes.

### Step 6: Review
Reviewer checks:
- logic quality
- code style
- scope drift
- unintended breakage
- test gaps

### Step 7: Summarize
Git Summarizer proposes commit message and human-readable change summary.

## Orchestration rules
- a plan is mandatory for large changes
- a reviewer pass is mandatory for multi-file changes
- browser tasks prefer MCP-based tooling
- screenshot analysis augments context but does not replace repo analysis
- all steps emit structured events
