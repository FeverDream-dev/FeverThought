# Bug Report

## Summary
## Expected behavior
## Actual behavior
## Steps to reproduce
## Platform
## App version
## Logs/screenshots
## Provider/MCP context if relevant
## Additional notes
