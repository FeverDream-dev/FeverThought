# Editor Subsystem

## Core choice
Use Monaco for the primary editing experience because it provides a familiar editing model, powerful language-aware hooks, and robust in-browser editor capabilities.

## Responsibilities
- file loading and saving
- dirty-state tracking
- cursor/selection management
- split panes
- tabs
- minimap
- breadcrumbs
- diff view
- diagnostics rendering
- inline AI annotations later

## Monaco integration plan
- create a wrapper package inside `packages/editor`
- expose a stable API for open file, reveal range, apply edits, show markers
- keep editor theme derived from design tokens
- map LSP diagnostics into Monaco marker format
- build a command bridge for palette actions

## Performance constraints
- lazy-load larger grammars/features
- avoid full rerender of editor wrappers
- debounce file watcher updates
- separate large diff rendering from normal editing flows

## Future enhancements
- inline code generation previews
- ghost text suggestions
- AI-produced multi-file refactor navigator
- semantic regions for agent suggestions
