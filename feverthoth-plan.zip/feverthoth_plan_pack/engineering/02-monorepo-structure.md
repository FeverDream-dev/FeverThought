# Monorepo Structure

## Recommended layout
```text
feverthoth-ide/
  apps/
    desktop/
  crates/
    core/
    providers/
    agents/
    mcp/
    workspace/
    settings/
    security/
    git_tools/
    terminal/
  packages/
    ui/
    editor/
    design-system/
    shared-types/
  docs/
  scripts/
  .github/
```

## Why this split works
- Tauri-specific app glue lives in `apps/desktop`
- Rust domain crates are composable and testable
- frontend packages can share components cleanly
- editor-specific code remains isolated from general UI
- provider and MCP logic avoids bleeding into unrelated modules

## Crate responsibilities
### core
application orchestration, events, policies

### providers
adapter traits, request normalization, streaming contracts

### agents
agent roles, orchestration state machine, prompts

### mcp
server lifecycle, tool manifests, permission integration

### workspace
project index, file ops abstraction, tree models

### settings
profile resolution, defaults, migration logic

### security
redaction, permissions, secure storage interface

### git_tools
status, diff, commit helpers, branch operations

### terminal
PTY integration and session management

## Frontend package responsibilities
### ui
shared screens and layout components

### editor
Monaco integration, decorations, diff viewers, code actions UI

### design-system
tokens, surfaces, buttons, tabs, panels, states

### shared-types
TypeScript mirror types for serialized Rust contracts
