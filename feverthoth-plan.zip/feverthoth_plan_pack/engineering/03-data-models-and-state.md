# Data Models and State

## Core entities

### Workspace
```ts
type Workspace = {
  id: string
  rootPath: string
  name: string
  openedAt: string
  favorite?: boolean
  recentFiles: string[]
  detectedLanguages: string[]
}
```

### ProviderProfile
```ts
type ProviderProfile = {
  id: string
  provider: "ollama" | "zai" | "ollama-cloud" | "gemini" | "codex" | "openrouter"
  enabled: boolean
  defaultModel?: string
  fallbackModel?: string
  capabilityFlags: string[]
}
```

### AgentSession
```ts
type AgentSession = {
  id: string
  workspaceId?: string
  createdAt: string
  request: string
  assumptions: string[]
  clarificationState: "none" | "pending" | "resolved"
  plan?: Plan
  actions: AgentAction[]
}
```

### ScreenshotAnalysis
```ts
type ScreenshotAnalysis = {
  id: string
  source: "uploaded" | "captured"
  storedLocally: boolean
  provider: "ollama"
  model: string
  visibleText: string[]
  uiElements: string[]
  detectedErrors: string[]
  likelyContext: string
  userGoalHypothesis: string[]
  ambiguityFlags: string[]
  followupQuestions: string[]
}
```

## State split
- persistent settings state
- workspace/session state
- transient UI state
- agent execution state
- panel layout state
- diagnostics state

## Persistence boundaries
Persist:
- recent workspaces
- theme/settings
- provider profiles
- UI layout preferences
- agent history summaries (optional, configurable)

Do not persist by default:
- raw screenshots beyond explicit retention policy
- sensitive prompt attachments without user consent
- provider secrets in plain text

## Suggested frontend state strategy
- query/cache layer for async data
- small local store for layout and UI state
- event-driven updates from Rust backend
