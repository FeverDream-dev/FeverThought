# Plugin and Addon System

## Goal
Allow future growth without turning the app into an unbounded extension free-for-all on day one.

## Early addon targets
- AI provider adapters
- MCP server adapters
- language server packs
- themes
- command palette actions

## Design principles
- explicit capability declarations
- versioned contracts
- sandbox-friendly boundaries
- observability hooks
- disable/rollback friendly

## v1 scope
Create the interface layer and a small internal registry system, but do not commit to a public marketplace yet.

## Addon manifest sketch
```json
{
  "name": "provider-openrouter",
  "version": "0.1.0",
  "type": "provider",
  "capabilities": ["text", "tools", "streaming"],
  "entrypoint": "./index.js",
  "permissions": ["network", "provider-keys"]
}
```
