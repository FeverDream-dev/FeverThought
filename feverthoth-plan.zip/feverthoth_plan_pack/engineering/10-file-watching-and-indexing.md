# File Watching and Indexing

## Goals
- keep workspace state current
- avoid UI jank
- power search, tree updates, and agent context

## Rules
- debounce bursty file events
- ignore known junk directories
- expose indexing state to UI
- allow manual reindex
- maintain lightweight project summary for agents
