# Settings Storage

## Categories
- appearance
- editor
- workspace
- provider profiles
- local model preferences
- MCP settings
- privacy controls
- terminal
- git
- experimental flags

## Resolution order
1. built-in defaults
2. app-level persisted preferences
3. workspace-level overrides
4. temporary session overrides

## Storage rules
- structured settings file for non-secret prefs
- OS secure storage/keychain for secrets when possible
- explicit migration versioning
- import/export for settings profiles later

## Critical preferences
- default local model
- default cloud model/provider
- screenshot sharing policy
- auto-plan mode
- ask-confirmation thresholds
- reduced motion
- theme intensity
