# Security and Privacy

## Core promises
- screenshots remain local by default
- secret keys are not stored in plain text when secure storage is available
- destructive actions require confirmation
- model/provider usage is visible
- tool actions are logged

## Threat considerations
- accidental cloud transmission of sensitive data
- provider secret leakage
- prompt injection through repo content or web pages
- shell command misuse by agent workflows
- unsafe file operations at workspace boundaries

## Controls
- explicit allowlist for file access
- workspace root boundary checks
- confirmation for shell, delete, mass rename, git push
- secret scanning/redaction before cloud submission where practical
- per-provider privacy disclosure in setup UI

## Audit model
Every AI action should be represented as:
- user request
- agent decision
- tool chosen
- provider/model chosen
- files affected
- confirmation state
- final outcome
