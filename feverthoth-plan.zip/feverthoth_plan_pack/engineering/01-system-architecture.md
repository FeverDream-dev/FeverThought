# System Architecture

## High-level architecture

### Shell
Tauri application shell provides:
- native windowing
- filesystem access through controlled commands
- secure invocation boundary
- packaging/distribution

### Frontend
React + TypeScript application provides:
- UI composition
- editor layout
- settings screens
- AI interaction views
- visual theming/state display

### Rust core
Rust crates own:
- workspace services
- provider orchestration
- security-sensitive storage hooks
- MCP process supervision
- screenshot processing orchestration
- terminal/process management
- git service abstractions
- AI action permissioning

## Architectural layering

### Layer 1: UI
Responsible for rendering, user inputs, view state, and optimistic feedback.

### Layer 2: application services
Responsible for workflow orchestration:
- open project
- ask AI
- run screenshot analysis
- connect provider
- confirm action

### Layer 3: domain/core
Responsible for stable business logic:
- session model
- provider capability model
- agent pipeline orchestration
- tool routing policy
- settings resolution

### Layer 4: adapters/integrations
Responsible for:
- Ollama
- cloud providers
- MCP servers
- Git
- terminal
- local filesystem
- LSP processes

## Key system boundaries
- UI should not embed provider secrets.
- Provider adapters should normalize request/response behavior.
- MCP tools should be sandboxed through a controlled invocation model.
- Screenshot storage policy should be explicit and configurable.
- Agent system should emit structured events for logging and audit.

## Event model
Suggested internal event stream:
- workspace/opened
- provider/connected
- model/selected
- ai/requested
- ai/clarification_requested
- ai/plan_generated
- ai/tool_called
- ai/diff_ready
- ai/action_confirmed
- file/changed
- git/status_changed
- error/emitted

## Major runtime flows

### Ask AI to implement feature
1. User submits request
2. Intent classifier checks ambiguity
3. Clarification UI triggers if needed
4. Repo cartographer gathers context
5. Planner emits plan
6. User reviews/approves
7. Tool router chooses providers/tools
8. Implementer generates edits
9. Reviewer critiques diff
10. User accepts/rejects

### Analyze screenshot
1. User supplies screenshot or capture request
2. Local vision pipeline runs
3. Structured JSON summary is produced
4. Summary becomes context for text model
5. Raw image remains local unless permission changed

### Browser task
1. User asks web/UI task
2. Router prefers Playwright/Chrome MCP
3. Structured browser data collected
4. If unavailable, fallback to local vision if appropriate
