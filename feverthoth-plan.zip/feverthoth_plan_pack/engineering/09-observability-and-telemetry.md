# Observability and Telemetry

## Internal logging
Capture:
- startup lifecycle
- workspace indexing
- provider connectivity
- MCP startup/shutdown
- AI session events
- failed actions
- release build diagnostics

## User-visible logs
Expose:
- provider test logs
- MCP logs
- AI action history
- error reports
- release/build outputs

## Telemetry policy
Default to privacy-respecting minimal telemetry or opt-in telemetry only.
The product should be able to function without mandatory analytics.

## Metrics candidates
- startup time
- average AI round-trip latency
- local vision latency
- provider failure frequency
- command palette usage
- panel usage
- crash signatures
