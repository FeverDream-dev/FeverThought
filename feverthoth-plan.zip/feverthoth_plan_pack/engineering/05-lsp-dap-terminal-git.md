# LSP, DAP, Terminal, and Git

## Language Server Protocol
### MVP
- Rust Analyzer first-class support
- generalized LSP process adapter contract
- configurable paths/launch commands
- diagnostics, hover, definition, references, rename, formatting

### Adapter contract
Each language adapter should describe:
- server binary discovery
- startup command
- initialization options
- file-type associations
- capability map
- shutdown policy

## Debug Adapter Protocol
### MVP stance
Implement the abstraction layer and basic UI scaffolding before chasing full language coverage.

Required groundwork:
- session state model
- debug panel UI
- adapter registration
- logs and event traces

## Terminal
### Requirements
- multiple terminal sessions
- split terminal support later
- command execution from tasks/AI with approval path
- shell detection
- scrollback persistence optionally

### Security rule
AI-triggered terminal commands must require user review unless explicitly trusted.

## Git integration
### MVP
- current branch
- changed files
- staged/unstaged states
- diff preview
- commit input
- checkout/switch branches
- revert selected file/hunk later

### AI tie-in
The Git Summarizer agent should:
- describe what changed
- suggest commit messages
- summarize risk areas
