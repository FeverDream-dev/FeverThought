# Accessibility

## Baseline standards
Target WCAG 2.2 AA where practical for the desktop app UI.

## Critical requirements
- maintain readable contrast despite translucent surfaces
- visible focus states on every interactive element
- full keyboard navigation for primary flows
- avoid communicating status through color alone
- reduced motion mode
- screen-reader-friendly labels for core controls

## Gloss-specific cautions
- reflections must never interfere with text contrast
- blur must not obscure boundaries
- gradients should not become semantic indicators on their own
- glass effects must degrade cleanly on lower-end systems

## AI UX accessibility
- clarification prompts must be keyboard selectable
- long plans should support structured headings and jump links
- tool logs should be copyable and text-readable
