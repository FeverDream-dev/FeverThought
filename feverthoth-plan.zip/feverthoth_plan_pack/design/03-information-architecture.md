# Information Architecture

## Primary layout
- left sidebar: project tree / search / source control
- center: editor stack
- right utility area: AI / outline / inspector
- bottom panel: terminal / problems / output / logs
- top app bar: project controls, run/build, provider badge, command access
- status bar: branch, diagnostics, language mode, provider state, model state

## Top-level navigation
- Explorer
- Search
- Source Control
- AI
- Run/Debug
- Extensions/Addons (later)
- Settings

## AI area modes
- Chat / intent intake
- Plan
- Actions / tool log
- Diffs / review
- Clarification prompts
- Session memory/context

## Settings structure
- General
- Appearance
- Editor
- Keybindings
- AI Providers
- Local Models
- MCP Tools
- Privacy & Security
- Git
- Terminal
- Experimental

## Command palette scope
- file actions
- editor actions
- workspace actions
- AI actions
- MCP actions
- provider switch actions
- theme switching
