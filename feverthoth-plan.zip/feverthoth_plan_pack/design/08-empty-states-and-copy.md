# Empty States and Copy

## Principles
- friendly but not childish
- plain language first
- explain what the user can do next
- avoid buzzword overload

## Example empty states

### No project open
“Open a folder to start building. FeverThoth works best when it can see your workspace.”

### No AI provider configured
“Connect a local or cloud model to unlock planning, code assistance, and screenshot interpretation.”

### Ollama not found
“We couldn’t detect Ollama on this machine yet. You can keep going with cloud providers, or install Ollama for local-first AI.”

### AI needs clarification
“I can help with that, but I need one detail first so I don’t make the wrong change.”

## Tone guide
Preferred:
- clear
- supportive
- specific

Avoid:
- smug copy
- excessive jokes
- fake certainty
- unexplained jargon
