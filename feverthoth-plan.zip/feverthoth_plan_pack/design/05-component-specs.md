# Component Specs

## App frame
- glossy header band
- project title
- active workspace indicator
- provider/model chip
- run/build buttons
- command access affordance

## Sidebar item
States:
- resting
- hover
- active
- attention
- disabled

Requirements:
- icon plus label
- active state should feel luminous, not neon
- keyboard navigation visible

## Editor tabs
- rounded chrome-like tabs
- active tab uses brighter glass fill
- unsaved dot indicator
- close affordance
- horizontal overflow support

## AI message block
Must support:
- role label
- model/provider badge
- timestamp
- plan/action sections
- tool call chips
- diff references
- confidence/assumption notes

## Clarification widget
Must support:
- question text
- 3+ suggested options
- custom input
- confirm/cancel
- optional “why I’m asking” hint
- option to continue with best guess

## Diff card
- file name
- change summary
- expandable hunk preview
- accept/reject or apply all
- associated agent/action metadata

## Provider card
- provider name
- auth state
- supported capabilities
- preferred models
- test connection button
- default/fallback toggles

## MCP status card
- server name
- installed/running state
- permission state
- tool count
- last error
- open logs
