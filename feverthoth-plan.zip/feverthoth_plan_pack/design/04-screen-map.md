# Screen Map

## Initial screens
1. Splash / loading
2. First-run onboarding
3. Provider setup wizard
4. Open project / recent projects
5. Main IDE shell

## Main shell views
- empty project state
- active project state
- AI tab focused state
- terminal-focused state
- git review state
- screenshot analysis state
- browser tool inspection state

## Key modals
- confirmation dialog
- screenshot cloud upload consent
- provider key setup
- model picker
- clarification prompt modal/inline drawer
- release notes / update dialog

## Settings screens
- appearance panel with theme preview
- AI provider configuration table
- local model diagnostics
- MCP server status
- privacy controls
- keyboard shortcut editor

## Edge states
- no internet
- Ollama not installed
- provider auth failed
- workspace indexing incomplete
- LSP unavailable
- model missing locally
- MCP unavailable
- unsupported platform packaging warning
