# Microinteractions

## Goals
Microinteractions should reinforce trust, state awareness, and delight without slowing work.

## Candidate moments
- provider connected successfully
- local model detected
- plan approved
- changes applied
- screenshot analyzed
- browser tool attached
- release build started/completed

## Motion language
- soft upward fade for success
- precise scale-and-glow for selected controls
- quick pulse for new AI clarification request
- subtle tab sheen for active focus, no continuous distracting animation

## Haptics equivalent in desktop terms
Use concise auditory or visual confirmation only if optional and tasteful. Default to visual only.
