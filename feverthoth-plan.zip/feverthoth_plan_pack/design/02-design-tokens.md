# Design Tokens

## Color tokens
```yaml
color:
  bg:
    app: "#dff4ff"
    workspace: "#f6fdff"
    panel: "rgba(255,255,255,0.72)"
    panelStrong: "rgba(255,255,255,0.86)"
  text:
    primary: "#11324a"
    secondary: "#355a72"
    muted: "#5f7e95"
    inverse: "#ffffff"
  accent:
    blue: "#3fb9ff"
    cyan: "#5ce1e6"
    green: "#68e6b1"
    gold: "#ffd36b"
  status:
    success: "#4bc98a"
    warning: "#ffbe55"
    danger: "#ff6c7a"
    info: "#53a9ff"
```

## Radius tokens
```yaml
radius:
  xs: 6
  sm: 10
  md: 14
  lg: 18
  xl: 24
  pill: 999
```

## Shadow tokens
```yaml
shadow:
  soft: "0 8px 24px rgba(44, 112, 150, 0.12)"
  medium: "0 12px 32px rgba(36, 89, 120, 0.18)"
  focus: "0 0 0 3px rgba(83, 169, 255, 0.32)"
  insetGloss: "inset 0 1px 0 rgba(255,255,255,0.65)"
```

## Blur/translucency tokens
```yaml
material:
  blurSm: "blur(8px)"
  blurMd: "blur(14px)"
  blurLg: "blur(24px)"
  borderGlass: "1px solid rgba(255,255,255,0.45)"
```

## Motion tokens
```yaml
motion:
  fast: 120ms
  base: 180ms
  slow: 260ms
  spring:
    stiffness: 220
    damping: 24
```

## Usage rules
- Never stack more than two shadow treatments on one element.
- Use the strongest gloss treatment only on top-level surfaces and active tabs.
- Keep destructive controls less glossy and more explicit.
