# Visual Direction

## Theme goal
Create a premium interpretation of **Frutiger Aero meets developer tool**.

## Primary visual ingredients
- translucent layered panels
- glossy highlights
- bright but controlled gradients
- rounded corners
- soft inner and outer shadows
- luminous cyan/green/blue accenting
- polished chrome-inspired separators
- calm depth cues

## Influence references
- Windows XP/Vista era shells
- glassmorphism before flat minimalism existed
- optimistic 2000s software futurism
- clean dashboard interfaces with physicality

## Design rules
- high contrast for text despite the glossy look
- large hit targets
- obvious hierarchy
- restrained motion
- use texture sparingly
- avoid cluttered skeuomorphism
- do not mimic old UI bugs or poor density decisions

## Surface taxonomy
### Primary window shell
Outer chrome/frame area, subtle reflection, most premium treatment.

### Workspace surface
Softer glass panel with strong content clarity.

### Elevated utility panels
Command palette, settings modals, AI clarification prompts.

### Accent callouts
Small use of vibrant green/cyan glow for active or successful states.

## Color direction
### Core hues
- sky blue
- cyan
- aqua green
- soft silver
- cloud white
- deep navy for contrast

### Accent hues
- electric teal
- aurora green
- polished amber for warnings
- ruby for destructive states

## Typography
Use a highly legible sans-serif stack. The tone should feel crisp, luminous, and clean.

## Icon direction
- glossy but not cartoonish
- readable at small sizes
- avoid over-detail
- use subtle colored fills for major categories

## Motion
- slow shimmer or sheen only where it adds delight
- panel openings should feel smooth and light
- destructive prompts should snap into focus, not drift
