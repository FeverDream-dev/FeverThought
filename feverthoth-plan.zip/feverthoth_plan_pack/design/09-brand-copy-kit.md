# Brand Copy Kit

## Short description
A luminous AI-first Rust IDE for planning, building, and shipping software beautifully.

## Medium description
FeverThoth IDE combines a serious editor, agentic AI workflows, local-first visual understanding, and a premium retro-futurist interface that stands apart from generic coding tools.

## Website hero options
- Think first. Build beautifully.
- Local insight. Cloud power. Better flow.
- The AI-first Rust IDE with a lucid glow.

## Store/release copy notes
Highlight:
- local Ollama support
- plan-before-edit AI
- cross-platform releases
- Frutiger Aero-inspired look
