# Jobs To Be Done

## Functional jobs

### When I open a project
I want the IDE to quickly understand the workspace, index the structure, and get me to a productive state.

### When I ask the AI for help
I want it to understand the repo and ask clarifying questions before touching code.

### When I am building UI
I want the system to inspect what is on screen and help me improve it.

### When I am stuck
I want errors, logs, code context, and the AI planner to converge into a useful next step.

### When I am shipping
I want git, tasks, builds, and release notes to feel connected rather than scattered across tools.

## Emotional jobs
- make me feel capable
- reduce “blank page” anxiety
- make hard technical work feel more guided
- give me confidence that the AI is not freelancing recklessly
- let me enjoy the environment I work in

## Social jobs
- help me share polished diffs and plans with collaborators
- produce explainable outputs, not mystery changes
- make it easier to hand work to teammates

## Success signals
- less time spent clarifying with the AI after the first prompt
- fewer accidental edits
- faster navigation through unfamiliar repos
- stronger trust in generated code
- repeat daily use instead of novelty-only usage
