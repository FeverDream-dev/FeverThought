# Branding and Naming

## Working brand
**FeverThoth IDE**

## Why this works
- “Fever” connects directly to FeverDream
- “Thoth” evokes knowledge, writing, records, and intelligence
- the name sounds premium and unusual
- it reads as a tool brand, not a gimmick
- it supports strong iconography

## Brand adjectives
- lucid
- glossy
- wise
- fast
- magical but trustworthy
- premium
- retro-futurist
- luminous

## Naming alternatives
### Strong alternatives
- DreamThoth
- ThothForge
- FeverRa
- FeverAnkh
- GlassThoth

### Why they rank lower
- some are less tool-like
- some lean too fantasy
- some feel less memorable
- some do not tie to coding/writing as naturally

## Tagline directions
- “Plan beautifully. Build fearlessly.”
- “The AI-first Rust IDE with a lucid glow.”
- “Think first. Code better.”
- “A brighter kind of coding.”
- “Local insight. Cloud power. Better flow.”

## Visual motifs
- glass panels
- azure/cyan/green gradients
- gold accents used sparingly
- subtle hieroglyph-inspired divider motifs, but never kitsch
- glossy lens flare-like highlights
- polished status lights
- tab and window treatments inspired by XP/Vista chrome

## Logo directions
### Option A: Feather + eye
A simplified feather quill with an illuminated circular lens/eye, blending writing and perception.

### Option B: Glass scarab
A stylized scarab with a glossy shell used subtly, abstracted enough to feel modern.

### Option C: Thoth glyph monogram
A polished “FT” monogram with a luminous horizon arc behind it.

## Brand hazards to avoid
- overly literal Egyptian clipart
- gaudy gold-on-black cliché styling
- excessive “gamer” aesthetics
- humor that reduces trust
- flat monochrome corporate UI drift
