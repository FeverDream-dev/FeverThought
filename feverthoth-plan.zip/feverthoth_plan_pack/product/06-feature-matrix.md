# Feature Matrix

## Core IDE
| Capability | MVP | V1 | Later |
|---|---|---|---|
| Open folder/workspace | Yes | Yes | — |
| Monaco editor | Yes | Yes | — |
| Tabs/splits | Yes | Yes | — |
| Search/replace | Yes | Yes | — |
| Terminal | Yes | Yes | — |
| Settings UI | Yes | Yes | — |
| Recent projects | Yes | Yes | — |
| Minimap | Yes | Yes | — |

## Intelligence
| Capability | MVP | V1 | Later |
|---|---|---|---|
| Rust Analyzer | Yes | Yes | — |
| General LSP adapter system | Yes | Yes | — |
| Formatting/code actions | Partial | Yes | — |
| DAP abstraction | Partial | Yes | More adapters |
| Tree-sitter structure | Yes | Yes | More language grammars |

## AI
| Capability | MVP | V1 | Later |
|---|---|---|---|
| Ollama local text | Yes | Yes | — |
| Local screenshot interpretation | Yes | Yes | More models |
| Cloud providers | 2+ | 5 | More |
| Plan-first AI workflow | Yes | Yes | — |
| Multi-agent routing | Partial | Yes | Smarter policy layer |
| Clarification widget | Yes | Yes | Deeper adaptive questioning |

## MCP
| Capability | MVP | V1 | Later |
|---|---|---|---|
| Playwright MCP | Partial | Yes | richer recording |
| Chrome DevTools MCP | Partial | Yes | deeper automation |
| AgentMCP slot | Architecture | Yes | richer marketplace |
| ThinkinMCP slot | Architecture | Yes | pluggable reasoning tools |

## Distribution
| Capability | MVP | V1 | Later |
|---|---|---|---|
| Windows builds | Yes | Yes | Signing polish |
| macOS builds | Yes | Yes | notarization hardening |
| Linux AppImage | Yes | Yes | — |
| Linux DEB | Yes | Yes | — |
| Linux RPM | Yes | Yes | — |
| Auto-updater | No | Partial | Yes |
