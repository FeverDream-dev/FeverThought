# Non-goals

## Not in the first release
- a full VS Code extension compatibility layer
- a huge public marketplace on day one
- collaborative real-time editing
- built-in cloud sync of every artifact
- own hosted model runtime
- enterprise policy controls
- mobile version
- browser version
- dozens of bundled language servers
- over-abstracting every provider before learning from use

## Important restraint rules
- Do not try to support everything in one cycle.
- Do not turn the design language into a parody.
- Do not overfit to one provider.
- Do not sacrifice trust for convenience.
- Do not hide complexity by making behavior opaque.

## What to defer intentionally
- advanced debugger UX
- extension marketplace
- organization/team features
- billing/subscription systems
- telemetry-heavy product analytics
