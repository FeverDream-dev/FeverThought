# Personas

## Persona 1: The vibe coder
### Profile
A builder who thinks in outcomes before architecture and wants the AI to help shape the implementation.

### Needs
- clarification help
- tool-guided generation
- low setup friction
- strong UI understanding
- simple language

### Frustrations
- AI that edits too fast
- poor repo understanding
- overwhelming settings
- cryptic dev tooling

## Persona 2: The indie product engineer
### Profile
A solo founder or tiny-team engineer shipping across frontend, backend, and infra.

### Needs
- reliable code navigation
- good terminal and git support
- AI that can plan refactors
- browser automation/testing support
- clean release packaging

### Frustrations
- unstable agents
- editor bloat
- fragmented provider setup
- context loss between sessions

## Persona 3: The design-minded developer
### Profile
Someone who cares deeply about visual quality and wants AI assistance for UI iteration.

### Needs
- screenshot interpretation
- browser tooling
- style-aware editing
- pleasant UI environment
- fast “change and inspect” loop

### Frustrations
- ugly tools
- AI that cannot read layouts
- weak visual feedback
- over-terminalized workflows

## Persona 4: The privacy-conscious builder
### Profile
A user who wants local-first AI when possible.

### Needs
- Ollama support
- clear cloud permission prompts
- screenshot locality
- explicit provider routing
- audit log

### Frustrations
- hidden uploads
- unclear data flow
- forced cloud dependency

## Persona 5: The advanced dev who still wants control
### Profile
A strong developer who likes agentic assistance but will reject a tool that feels fake or restrictive.

### Needs
- real IDE features
- model choice
- diff visibility
- terminal access
- plugin/addon growth path

### Frustrations
- toy UX
- locked workflows
- fake IDE functionality
- lack of transparency
