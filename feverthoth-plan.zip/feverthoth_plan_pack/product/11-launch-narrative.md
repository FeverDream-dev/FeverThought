# Launch Narrative

## Positioning story
FeverThoth IDE is not “yet another AI editor.” It is a deliberate answer to three gaps:
1. AI tools that rush into code without clarification
2. developer tools that all look emotionally interchangeable
3. privacy-sensitive users forced into cloud-only workflows

## Press/demo angle
- a beautiful AI-first Rust IDE
- local screenshot understanding with cloud planning optional
- agentic vibe coding with better clarification
- downloadable builds for real users, not source-only enthusiasts

## Demo script outline
1. open project
2. ask vague feature request
3. AI asks a good clarifying question
4. planner proposes a plan
5. local screenshot is analyzed
6. MCP browser tool inspects running app
7. code changes reviewed
8. commit summary generated
