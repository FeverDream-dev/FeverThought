# Product Vision

## Vision statement

Build the most emotionally distinctive AI-first Rust IDE on the market: one that feels **powerful, clear, beautiful, and alive** rather than cluttered, flat, and generic.

## Why this product should exist

There is space between:
- mainstream code editors that added AI as a sidebar feature
- heavy enterprise IDEs
- terminal-centric agent tools
- toy “build with prompts” apps

FeverThoth IDE should occupy that space by combining:
- a full editor experience
- strong AI orchestration
- local model privacy paths
- friction-reducing clarification UX
- nostalgic but premium visual identity

## Vision in plain language

The user should feel:
- “I can actually build things here.”
- “The AI understands what I mean, not just what I typed.”
- “This looks special.”
- “I am not forced into the cloud for everything.”
- “I can stay in flow without losing trust.”

## Product principles

### Planning beats guessing
The AI must not rush into file edits on vague requests.

### Beauty is functional
The visual identity must improve memorability, approachability, and delight.

### Transparency beats magic
Users should see:
- what model was used
- what tools were used
- what files changed
- what assumptions were made

### Local-first where privacy matters
Screenshots and sensitive visual context stay local by default.

### Extensibility beats lock-in
Provider integrations, MCP tools, and addon points should be easy to extend later.

## Experience promise

When a user asks:
> “Make this page feel more premium and fix the broken auth flow”

the IDE should be able to:
1. inspect the repo
2. inspect the running UI if available
3. clarify ambiguous goals
4. propose a plan
5. make edits
6. summarize results
7. help the user verify the changes

## Anti-vision

Do **not** build:
- a generic VS Code clone with a skin
- a shallow AI chat panel with no tool intelligence
- a flat design system with a few gradients pasted on top
- a provider spaghetti app with insecure key handling
- a release process that forces users to compile from source
