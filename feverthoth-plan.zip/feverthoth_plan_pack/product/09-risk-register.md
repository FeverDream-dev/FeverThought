# Risk Register

## Product risks

### Risk: Too much ambition in v1
**Impact:** delays, half-built features, unstable releases  
**Mitigation:** phase delivery, ruthless MVP boundary, explicit defer list

### Risk: AI feels slow because of plan-first behavior
**Impact:** some users perceive friction  
**Mitigation:** let users choose quick mode vs plan mode while keeping safe defaults

### Risk: Retro styling hurts usability
**Impact:** novelty without long-term trust  
**Mitigation:** tokenized design system, accessibility reviews, strict interaction clarity

## Technical risks

### Risk: Tauri/WebView differences across OSes
**Mitigation:** CI across target platforms, documented known differences, visual regression testing

### Risk: MCP tool stability
**Mitigation:** isolate in adapters, graceful degradation, logging, permission gating

### Risk: model/provider volatility
**Mitigation:** capability flags, normalized errors, provider abstraction, fallback policy

### Risk: local vision too slow on weaker machines
**Mitigation:** configurable model defaults, lightweight fallback, progressive result strategy

## Business/operational risks

### Risk: code signing/notarization friction
**Mitigation:** prepare hooks early, document secrets and manual steps

### Risk: support burden from cross-platform packaging
**Mitigation:** support matrix, runbooks, issue templates, build provenance docs
