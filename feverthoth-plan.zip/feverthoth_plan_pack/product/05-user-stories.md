# User Stories

## Onboarding
- As a new user, I want the app to detect whether Ollama is installed so I know what works locally right away.
- As a new user, I want a friendly provider setup wizard so I am not confronted with raw configuration forms.

## Editing
- As a developer, I want autocomplete and auto-closing pairs so routine coding feels fluid.
- As a developer, I want multi-tab and split views so I can compare files and edits easily.

## Navigation
- As a developer, I want go-to-definition and symbol search so I can understand an unfamiliar repo.
- As a developer, I want breadcrumbs and outline views so I can keep track of my location in large files.

## AI planning
- As a user, I want the AI to explain its plan before making a large refactor.
- As a user, I want the AI to ask follow-up questions when my request is ambiguous.

## Visual context
- As a UI builder, I want the AI to understand a screenshot locally and describe what it sees.
- As a UI builder, I want the browser tool path to be preferred when the task is truly about the web page state.

## Trust
- As a privacy-conscious user, I want screenshots to stay local by default.
- As a cautious user, I want destructive operations to require approval.
- As a technical user, I want to know which provider/model handled each step.

## Release
- As a user, I want downloadable builds for my OS so I do not have to compile the app.
