# Competitive Benchmark

## Reference set
- VS Code
- Cursor
- Windsurf
- Zed
- JetBrains AI-enabled IDEs
- OpenCode / terminal-agent workflows

## What to learn from them
### VS Code
- practical editor expectations
- workspace ergonomics
- familiar panel metaphors

### Cursor / Windsurf
- tighter AI-in-editor workflows
- contextual code actions
- faster prompt-to-patch interaction

### Zed
- speed
- modern editor performance expectations

### JetBrains family
- deeper IDE correctness expectations
- serious navigation and refactoring credibility

### OpenCode-style tools
- agent-centric command patterns
- repo-scoped tool usage
- plan-and-execute interaction style

## What not to copy blindly
- generic dark UI sameness
- shallow chat sidebars
- provider opacity
- “AI magic” without user trust controls
- over-reliance on text-only world models for visual tasks

## Strategic gap to occupy
A product that is:
- more beautiful than the mainstream coding tool baseline
- more structured than a casual AI chat editor
- more approachable than terminal-only agent tooling
- more privacy-aware than cloud-only assistants
