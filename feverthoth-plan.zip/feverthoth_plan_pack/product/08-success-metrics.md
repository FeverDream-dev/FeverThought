# Success Metrics

## Product metrics
- installation success rate by platform
- time-to-first-project-open
- time-to-first-successful-AI-assisted edit
- percentage of AI sessions that start with clarification when ambiguity exists
- percentage of accepted AI plans
- percentage of reverted AI edits

## Quality metrics
- crash-free sessions
- provider error rate
- release artifact integrity
- LSP responsiveness
- startup time
- memory footprint under normal usage

## Trust metrics
- percentage of users who keep screenshot upload set to local-only
- destructive-action confirmation rate
- diff preview usage rate
- audit log view rate

## Adoption metrics
- weekly active users
- repeat session rate
- provider mix by local vs cloud
- projects opened per user
- retention after first week

## Qualitative success
- users describe the app as “beautiful,” “clear,” and “thoughtful”
- users feel the AI is unusually good at asking clarifying questions
- users report confidence in provider visibility and local-first options
