# Packaging Matrix

## Windows
### Primary target
- EXE installer

### Secondary target
- MSI if practical and worth maintaining

### Notes
- signing should be planned early even if not available immediately
- verify install/uninstall paths
- test on fresh Windows VM

## macOS
### Primary target
- DMG

### Architecture targets
- Apple Silicon
- Intel if still within support goals

### Notes
- notarization and signing hooks should exist from the start
- test install from downloaded artifact, not only local build

## Linux
### Primary targets
- AppImage
- DEB
- RPM

### Notes
- older Linux build environments may improve compatibility
- publish support matrix and known caveats

## Distribution strategy
Use GitHub Releases as the default download source for early stages.
