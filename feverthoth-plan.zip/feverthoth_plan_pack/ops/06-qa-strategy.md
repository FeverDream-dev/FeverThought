# QA Strategy

## Test layers
- unit tests for Rust core crates
- component tests for React UI
- integration tests for provider adapters
- end-to-end smoke tests for core app flows
- packaging/install verification tests
- visual regression testing for key screens

## Highest-risk flows to cover first
- onboarding
- open project
- save file
- Rust Analyzer operational path
- AI clarification flow
- local screenshot analysis
- provider auth and fallback
- release install artifacts

## Manual QA essentials
- first-run flow on all OSes
- dark/light theme readability
- high DPI and small screen sanity checks
- keyboard-only navigation pass
- offline and partial-connectivity behavior
