# GitHub Actions Workflows

## Workflow set

### 1. `ci.yml`
Triggers:
- pull_request
- push to main

Jobs:
- frontend lint/test
- Rust fmt/clippy/test
- typecheck
- basic bundle smoke test if feasible

### 2. `release.yml`
Triggers:
- tags like `v*.*.*`
- manual dispatch

Jobs:
- matrix build for Windows/macOS/Linux
- Tauri bundle
- upload release artifacts
- publish checksums
- optional updater manifest

### 3. `nightly.yml`
Triggers:
- schedule
- manual dispatch

Jobs:
- build preview artifacts
- publish pre-release draft

### 4. `security.yml`
Triggers:
- schedule
- push
- pull_request

Jobs:
- cargo audit
- npm audit or policy scan
- CodeQL
- secret scanning support

## Artifact naming convention
`feverthoth-{version}-{platform}-{arch}.{ext}`

Examples:
- `feverthoth-0.1.0-windows-x64.exe`
- `feverthoth-0.1.0-macos-aarch64.dmg`
- `feverthoth-0.1.0-linux-x64.AppImage`
