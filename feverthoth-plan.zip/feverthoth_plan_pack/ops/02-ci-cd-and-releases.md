# CI/CD and Releases

## Goals
- every main branch change is validated
- tagged releases produce downloadable binaries/installers
- artifacts land in GitHub Releases
- release notes are generated cleanly
- failures are obvious and diagnosable

## Pipeline lanes
### CI lane
- install toolchains
- cache Rust and Node dependencies
- lint frontend/backend
- run tests
- smoke-build desktop app

### Release lane
- run on version tag or manual dispatch
- build Windows, macOS, Linux artifacts
- bundle per target
- upload to GitHub Release
- attach checksums
- optionally publish updater metadata

## Release philosophy
Prefer predictable, boring release automation over clever but fragile workflow YAML.

## Failure handling
- keep logs readable
- surface missing signing secrets clearly
- allow draft releases while signing/notarization matures
