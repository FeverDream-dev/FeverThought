# Test Matrix

## Platforms
- Windows x64
- macOS Apple Silicon
- macOS Intel if supported
- Linux x64

## Scenarios
- fresh install
- upgrade install
- launch without provider
- launch with Ollama only
- launch with cloud provider only
- launch with both local and cloud
- open small repo
- open medium repo
- AI plan request
- AI clarified request
- screenshot analysis
- browser MCP available
- browser MCP unavailable fallback
- git diff and commit flow

## Validation outcomes
For each scenario validate:
- app launches
- no blocking errors
- UI readable
- critical actions succeed
- logs understandable when failures happen
