# Support Runbooks

## Runbook: Ollama not detected
1. Check whether Ollama is installed.
2. Check whether the Ollama service is running.
3. Validate configured host/port.
4. Offer local diagnostics command or button.
5. Suggest cloud fallback if user wants to proceed immediately.

## Runbook: Provider auth failed
1. Re-test token
2. Check model availability
3. Check network
4. Normalize and display provider error
5. Suggest fallback provider if configured

## Runbook: MCP server unavailable
1. Show server status
2. Show last startup error
3. Offer restart
4. Offer fallback tool path
5. Capture logs for issue filing

## Runbook: Release artifact broken
1. Identify platform/build flavor
2. Check workflow logs
3. Confirm signing/notarization status
4. Compare checksum
5. re-run packaging job if necessary
