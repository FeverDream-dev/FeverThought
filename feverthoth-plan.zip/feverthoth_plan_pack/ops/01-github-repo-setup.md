# GitHub Repo Setup

## Recommended repo name
`feverthoth-ide`

## Initial labels
- type:bug
- type:feature
- type:design
- type:infra
- type:ai
- type:mcp
- type:release
- priority:p0
- priority:p1
- priority:p2
- status:blocked
- status:needs-design
- status:needs-spec

## Milestones
- MVP foundation
- AI-first workflow
- MCP integration
- packaging and release hardening
- beta
- v1.0

## Default branch policy
- `main` protected
- PR required
- CI required
- signed commits optional initially, later recommended

## Issue hygiene
Require every substantial feature issue to specify:
- user value
- acceptance criteria
- dependencies
- risk notes
