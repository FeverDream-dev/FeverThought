# Versioning and Release Train

## Versioning
Use SemVer:
- MAJOR for breaking changes
- MINOR for feature releases
- PATCH for fixes

## Channels
- nightly
- beta
- stable

## Suggested early cadence
- weekly internal milestone review
- biweekly beta candidates once installer quality is reasonable
- stable releases only when all major platforms pass smoke tests

## Release readiness gate
- build artifacts generated
- smoke install tested
- critical bugs triaged
- changelog prepared
- rollback plan available
