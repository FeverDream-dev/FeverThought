# Documentation Publishing

## Goal
Keep docs close to the repo and publish selected docs to a docs site later.

## Early recommendation
- keep authoritative engineering docs in-repo
- publish user-facing install docs and FAQ
- keep planning pack versioned with releases when major decisions change
