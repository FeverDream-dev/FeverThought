# FeverThoth IDE Planning Pack

This archive is a **planning-first blueprint** for building **FeverThoth IDE**, an AI-first, Rust-based, cross-platform IDE under the **FeverDream** organization.

## What is inside

This pack is intentionally split into many focused Markdown files so the team can:
- hand sections to different owners
- convert docs into GitHub issues and milestones
- feed targeted files into coding agents
- keep product, design, engineering, and release work aligned

## Recommended reading order

1. `INDEX.md`
2. `MASTER_BUILD_BRIEF.md`
3. `product/01-vision.md`
4. `design/01-visual-direction.md`
5. `engineering/01-system-architecture.md`
6. `ai/01-provider-abstraction.md`
7. `ops/02-ci-cd-and-releases.md`
8. `management/01-roadmap.md`

## Product summary

FeverThoth IDE is meant to be:
- **AI-first**
- **simple for normal people**
- **serious enough for advanced developers**
- **built with Rust/Tauri**
- **visually distinct with a Frutiger Aero / XP-Vista inspired interface**
- **capable of mixing local Ollama models with cloud coding providers**
- **agentic rather than “just chat in a sidebar”**

## Primary strategic choices

- Desktop shell: **Tauri v2**
- Core backend: **Rust**
- Frontend: **React + TypeScript + Vite**
- Editor: **Monaco**
- Syntax and structure support: **Tree-sitter**
- IDE intelligence: **LSP architecture**
- Local AI runtime: **Ollama**
- Default local vision model: **Qwen2.5-VL**
- MCP-first browser tooling: **Playwright MCP** and **Chrome DevTools MCP**
- Release distribution: **GitHub Actions + GitHub Releases**

## How to use this pack

- Use the docs as the source material for project kickoff.
- Turn sections in `management/05-backlog-epics.md` into GitHub issues.
- Use `ai/08-prompt-pack.md` and `MASTER_IMPLEMENTATION_PROMPT.md` with coding agents.
- Use `ops/04-github-actions-workflows.md` as the CI/CD build checklist.
- Use `templates/` to create follow-on specs and ADRs.

## Archive goals

This pack is designed to answer:
- What exactly are we building?
- Why does it deserve to exist?
- What makes it different?
- How should the system be architected?
- How do the AI layers work?
- How do we package and ship it?
- How do we sequence delivery without chaos?
