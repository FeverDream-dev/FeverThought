# Master Implementation Prompt

Use this file as the highest-level build prompt when bootstrapping the codebase with a coding agent.

## Prompt

Build a production-ready cross-platform desktop IDE called **FeverThoth IDE** for the GitHub org **FeverDream**.

### Mission
Create a real, runnable application that is:
- AI-first
- Rust-centered
- cross-platform
- easy for normal users
- serious enough for professional developers
- visually inspired by Windows XP/Vista era glassy Frutiger Aero aesthetics

### Required stack
- Tauri v2
- Rust backend/core
- React + TypeScript + Vite frontend
- Monaco Editor
- Tree-sitter
- LSP architecture with Rust Analyzer first
- integrated terminal
- Git support
- settings system
- provider abstraction for local and cloud AI
- GitHub Actions release workflows

### AI architecture
Implement:
- local Ollama support
- primary local screenshot vision model: qwen2.5-vl
- optional fallback local models: gemma3, llama3.2-vision
- cloud adapters for Z.AI Coding Plan, Ollama Cloud, Gemini, OpenAI Codex, OpenRouter
- MCP-native tool layer with Chrome DevTools MCP, Playwright MCP, ThinkinMCP slot, AgentMCP slot
- multi-agent vibe-coding pipeline with plan-first behavior

### AI agent roles
Implement these agent roles:
- Intent Clarifier
- Planner
- Repo Cartographer
- Tool Router
- Implementer
- Reviewer
- Browser/UI Agent
- Git Summarizer

### Critical behaviors
- Always clarify when the request is materially ambiguous.
- Provide at least 3 quick-select options in clarification UI when appropriate.
- Prefer Playwright MCP or Chrome DevTools MCP over screenshot vision for browser tasks.
- Keep screenshots local by default and only send structured summaries to cloud providers unless the user opts in.
- Show plan before major edits.
- Ask for confirmation before destructive actions.

### Core IDE feature target
Deliver practical parity with mainstream coding tools for:
- tabs
- split editor
- file explorer
- search/replace
- autocomplete
- go to definition
- rename
- hover docs
- diagnostics
- formatting
- bracket matching
- auto-closing pairs
- command palette
- terminal
- git panel
- status bar
- settings
- recent projects

### UX direction
The interface must feel:
- glossy
- rounded
- premium
- retro-futurist
- blue/green/cyan luminous
- not flat
- not generic

### Project output
Generate:
1. architecture summary
2. repository tree
3. runnable implementation
4. setup instructions
5. GitHub Actions workflows
6. packaging config
7. provider interfaces
8. initial agent prompts/system logic
9. clarification widget
10. first-run onboarding
11. README

### Delivery preference
Work in phases but keep each phase runnable:
- phase 1 foundation
- phase 2 AI and MCP expansion
- phase 3 hardening and release polish

### Quality bar
The result should feel like a real product that can ship, not an experiment or mockup.
